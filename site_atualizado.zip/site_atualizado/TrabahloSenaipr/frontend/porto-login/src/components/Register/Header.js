// Header.js
import React from 'react';


const Header = () => {
  return (
    <div className="header-container">
      <div className="header-title">Milkspace</div>
    </div>
  );
};

export default Header;
