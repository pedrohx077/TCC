// src/components/Footer.js
import React from 'react';

const Footer = () => {
  return (
    <div style={{ width: '100%', height: 109, position: 'relative' }}>
      <div style={{
        width: '100%',
        height: 109,
        position: 'absolute',
        background: '3ec8c1'
      }} />
    </div>
  );
};

export default Footer;
